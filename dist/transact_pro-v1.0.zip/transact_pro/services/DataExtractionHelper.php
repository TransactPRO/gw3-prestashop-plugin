<?php

class DataExtractionHelper
{
    /**
     * @param Cart $cart
     * @param Currency $currency
     * @return array
     */
    public static function extractPaymentData($cart, $currency) {
        $total = number_format($cart->getOrderTotal(true, Cart::BOTH), 2, '.', '');
        $data = array(
            'amount' => $total,
            'currency' => $currency->iso_code
        );

        $data['payment_instrument'] = array(
            'pan' => strip_tags(str_replace(' ', '', Tools::getValue('card_pan'))),
            'exp_year' => (string)Tools::getValue('expiration_year'),
            'exp_month' => sprintf("%02d", (string)Tools::getValue('expiration_month')),
            'cvc' => strip_tags(trim(Tools::getValue('cvc'))),
            'holder' => strip_tags(trim(Tools::getValue('card_holder')))
        );

        $data['customer'] = self::extractCustomerData($cart);

        return $data;
    }

    /**
     * @param Cart $cart
     * @return array
     */
    public static function extractCustomerData($cart)
    {
        $defaultValue = ' ';

        $shippingAddress = new Address(intval($cart->id_address_delivery));
        $shippingCountry = new Country(intval($shippingAddress->id_country));

        $billingAddress = new Address(intval($cart->id_address_invoice));
        $billingCountry = new Country(intval($billingAddress->id_country));

        return array(
            'phone' => self::sanitize($shippingAddress->phone) ?: $defaultValue,
            'billing_address_country' => self::sanitize($billingCountry->iso_code),
            'billing_address_city' => self::sanitize($billingAddress->city) ?: $defaultValue,
            'billing_address_street' => self::sanitize($billingAddress->address1) ?: $defaultValue,
            'billing_address_house' => self::sanitize($billingAddress->address2) ?: $defaultValue,
            'billing_address_ZIP' => self::sanitize($billingAddress->postcode) ?: $defaultValue,
            'shipping_address_country' => self::sanitize($shippingCountry->iso_code),
            'shipping_address_city' => self::sanitize($shippingAddress->city) ?: $defaultValue,
            'shipping_address_street' => self::sanitize($shippingAddress->address1) ?: $defaultValue,
            'shipping_address_house' => self::sanitize($shippingAddress->address2) ?: $defaultValue,
            'shipping_address_ZIP' => self::sanitize($shippingAddress->postcode) ?: $defaultValue
        );
    }

    /**
     * @param string $value
     * @return string
     */
    private static function sanitize($value)
    {
        return preg_replace('/[^\w\d\s]/', ' ', (string) $value);
    }
}