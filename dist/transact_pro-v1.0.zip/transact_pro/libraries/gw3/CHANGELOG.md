##### Version 1.1.1 (2018-02-27)

	Minor fixes

##### Version 1.1.0 (2018-01-22)

	Add new methods for init recurrent SMS and init recurrent DMS

##### Version 1.0.0 (2017-11-10)

	First release
